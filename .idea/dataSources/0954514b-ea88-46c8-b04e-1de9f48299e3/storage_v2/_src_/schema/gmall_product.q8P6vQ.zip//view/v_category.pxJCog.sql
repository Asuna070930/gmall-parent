create definer = root@`%` view v_category as
select `c3`.`id`   AS `id`,
       `c1`.`id`   AS `category1Id`,
       `c1`.`name` AS `category1Name`,
       `c2`.`id`   AS `category2Id`,
       `c2`.`name` AS `category2Name`,
       `c3`.`id`   AS `category3Id`,
       `c3`.`name` AS `category3Name`
from ((`gmall_product`.`base_category1` `c1` join `gmall_product`.`base_category2` `c2`
       on ((`c1`.`id` = `c2`.`category1_id`))) join `gmall_product`.`base_category3` `c3`
      on ((`c2`.`id` = `c3`.`category2_id`)));

-- comment on column v_category.id not supported: 编号

-- comment on column v_category.category1Id not supported: 编号

-- comment on column v_category.category1Name not supported: 分类名称

-- comment on column v_category.category2Id not supported: 编号

-- comment on column v_category.category2Name not supported: 二级分类名称

-- comment on column v_category.category3Id not supported: 编号

-- comment on column v_category.category3Name not supported: 三级分类名称

